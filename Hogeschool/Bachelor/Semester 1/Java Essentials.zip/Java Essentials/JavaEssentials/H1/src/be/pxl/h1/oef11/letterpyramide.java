package be.pxl.h1.oef11;

public class letterpyramide {
    public static void main(String[] args) {

    }
}
