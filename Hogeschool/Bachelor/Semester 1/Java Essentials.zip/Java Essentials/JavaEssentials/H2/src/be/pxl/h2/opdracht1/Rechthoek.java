package be.pxl.h2.opdracht1;

public class Rechthoek {
    public int x;
    public int y;
    public int breedte;
    public int hoogte;

    public void setAfmetingen(int lengtefiguur, int breedtefiguur)
    {
        breedte = breedtefiguur;
        hoogte = lengtefiguur;
    }

}
