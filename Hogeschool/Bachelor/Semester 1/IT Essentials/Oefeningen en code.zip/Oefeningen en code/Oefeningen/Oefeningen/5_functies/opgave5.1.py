def printx():
    print("x")

def meerderex():
    for i in range(5):
        printx()

print(printx())
print(meerderex())