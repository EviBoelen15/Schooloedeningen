def main():
    nummer_lijst = [1, 2, 3, 4, 5]

    index = 0

    while index != len(nummer_lijst):
        print(nummer_lijst[index])

        index += 1

if __name__ == '__main__':
    main()