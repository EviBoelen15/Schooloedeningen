def main():
    tekst = input("Geef hier tekst in: ")
    print(tekst[::-1])

if __name__ == '__main__':
    main()