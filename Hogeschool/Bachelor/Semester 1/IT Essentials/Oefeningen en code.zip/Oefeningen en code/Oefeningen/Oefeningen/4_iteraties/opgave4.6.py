teller = 10
print(teller)
while (teller > 1):
    teller -= 1
    print(teller)
print("START")