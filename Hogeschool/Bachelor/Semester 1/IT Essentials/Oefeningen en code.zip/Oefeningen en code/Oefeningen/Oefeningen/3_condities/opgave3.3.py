t = True
f = False
print(t and t)
print(t and f)
print(f and t)
print(f and f)
print(t or t)
print(t or f)
print(f or t)
print(f or f)
print(not t)
print(not f)