getallen_lijst = [1, 4, 5, 6, 7]

print(getallen_lijst)

for i in range(len(getallen_lijst)):
    print(i, end=" ")
    print(getallen_lijst[i])