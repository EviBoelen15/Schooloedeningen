var1 = int(input("Geef variabele 1: "))
var2 = int(input("Geef variabele 2: "))
var3 = int(input("Geef variabele 3 "))

gemiddelde = ((var1 + var2 + var3)/3)

print(gemiddelde)