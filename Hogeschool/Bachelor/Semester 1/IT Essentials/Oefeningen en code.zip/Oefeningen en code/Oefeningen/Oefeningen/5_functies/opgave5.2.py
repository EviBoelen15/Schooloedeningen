
def is_even(num):
    if num % 2 == 0:
        return "true"
    else:
        return "false"


getal = int(input("Geef getal: "))
print(is_even(getal))
