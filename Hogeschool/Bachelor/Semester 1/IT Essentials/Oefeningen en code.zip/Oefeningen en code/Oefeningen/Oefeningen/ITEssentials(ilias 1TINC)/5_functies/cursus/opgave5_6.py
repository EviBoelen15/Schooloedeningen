def get_tienden(getal):
    return (getal * 10) % 10

getal = 45.235
print(round(get_tienden(getal)))
