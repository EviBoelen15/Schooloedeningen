def main():
    tekst = "banaan"
    print(tekst, "\nde lengte van het woord: ", len(tekst))

if __name__ == '__main__':
    main()