def main():
    fruitlist = ["appel", "banaan", "kers", "mandarijn", "mango"]
    for element in fruitlist:
        print(element)
        element = element.upper()
        print(element)


if __name__ == '__main__':
    main()