for i in range(3):
    for j in range(3):
        for k in range(3):
            print("(" + str(i) + "," + str(j) + "," + str(k) + ")")