PI = 3.14159

straal = int(input("Geef de straal van de circel: "))

oppervlakte = straal ** 2 * PI

print(oppervlakte)