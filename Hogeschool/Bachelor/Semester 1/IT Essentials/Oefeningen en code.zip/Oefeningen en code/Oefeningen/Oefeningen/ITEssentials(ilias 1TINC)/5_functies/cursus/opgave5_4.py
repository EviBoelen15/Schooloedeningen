from random import random

def is_even(getal):
    # if getal % 2 == 0:
    #     return True
    # return False
    return getal % 2 == 0

print(is_even(2))
print(is_even(3))
print(is_even(4))

getallen = random()

for i in range(1, 6):
    print(getallen)