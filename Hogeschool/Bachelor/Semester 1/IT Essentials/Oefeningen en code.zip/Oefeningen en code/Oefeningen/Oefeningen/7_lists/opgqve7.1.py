def main():
    lijstelement = ["NA", "CO2", "O", "He", "Si", "Al"]
    teller = 0
    while teller < len(lijstelement):
        print(lijstelement[teller])
        teller += 1


if __name__ == "__main__":
    main()