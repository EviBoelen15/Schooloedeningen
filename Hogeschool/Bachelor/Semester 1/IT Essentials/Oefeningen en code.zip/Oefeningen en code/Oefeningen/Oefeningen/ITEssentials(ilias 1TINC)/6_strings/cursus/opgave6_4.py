def main():
    spreuk = "  aBRAcaDAbra  "
    print(spreuk.strip())
    print(spreuk.strip().upper())
    print(spreuk.strip().lower())

if __name__ == '__main__':
    main()