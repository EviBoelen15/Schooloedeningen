num = 1
while num <= 9 :
    print(num)
    num += 2
print("Klaar")