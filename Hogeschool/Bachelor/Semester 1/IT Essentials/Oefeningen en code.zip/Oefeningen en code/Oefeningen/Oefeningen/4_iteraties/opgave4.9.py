for x in range(21, 3, -3):
    print(x)