def groet(naam):
    print("Hallo, " + naam + "!")


groet("Groucho")
groet("Chico")
groet("Harpo")
groet("Zeppo")