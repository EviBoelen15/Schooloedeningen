totaal = 0
for x in range(5):
    getal = int(input("Geef een getal "))
    totaal += getal
print(totaal)