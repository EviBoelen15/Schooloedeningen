groter = 1/3 > 0.33
print(groter)
groter = 1/3 < 0.33
print(groter)
groter = 1/3 == 0.33
print(groter)

groter = 1/2 > 0.5
print(groter)
groter = 1/2 < 0.5
print(groter)
groter = 1/2 == 0.5
print(groter)
