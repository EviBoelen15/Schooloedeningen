﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace CS_Oefening_029
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private float getal1 = 0.0f;
        private float getal2 = 0.0f;

        public MainWindow()
        {
            InitializeComponent();
        }

        private void LeesGetallen(string getalTekst1, string getalTekst2)
        {
            getal1 = float.Parse(getalTekst1);
            getal2 = float.Parse(getalTekst2);
        }

        // char is een karakter (letter, symbool, cijfer,...)
        private float Berekenen(char teken)
        {
            switch (teken)
            {
                case '+':
                    return getal1 + getal2;
                case '-':
                    return getal1 - getal2;
                case '*':
                    return getal1 * getal2;
                case '/':
                    return getal1 / getal2;
                default:
                    // Functie method moet altijd een resultaat returnen!
                    return 0.0f;
            }
        }


        private void BtnPlus_Click(object sender, RoutedEventArgs e)
        {
            LeesGetallen(TxtGetal1.Text, TxtGetal2.Text);
            float resultaat = Berekenen('+');
            TxtResultaat.Text = resultaat.ToString();
            TxtGetal1.Focus();
        }

        private void BtnMin_Click(object sender, RoutedEventArgs e)
        {
            LeesGetallen(TxtGetal1.Text, TxtGetal2.Text);
            float resultaat = Berekenen('-');
            TxtResultaat.Text = resultaat.ToString();
            TxtGetal1.Focus();
        }

        private void BtnMaal_Click(object sender, RoutedEventArgs e)
        {
            LeesGetallen(TxtGetal1.Text, TxtGetal2.Text);
            float resultaat = Berekenen('*');
            TxtResultaat.Text = resultaat.ToString();
            TxtGetal1.Focus();
        }

        private void BtnDeel_Click(object sender, RoutedEventArgs e)
        {
            LeesGetallen(TxtGetal1.Text, TxtGetal2.Text);
            float resultaat = Berekenen('/');
            TxtResultaat.Text = resultaat.ToString();
            TxtGetal1.Focus();
        }

        private void BtnWissen_Click(object sender, RoutedEventArgs e)
        {
            TxtGetal1.Text = "0";
            TxtGetal2.Text = "0"; 
            TxtResultaat.Clear(); 
            TxtGetal1.Focus();
        }
    }
}
