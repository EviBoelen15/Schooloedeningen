﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace CS_Oefening_028
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        // Void-methode
        private void ToonInkomen(int jaarsalaris, int aantalJaren)
        {
            int inkomen = jaarsalaris * aantalJaren;
            TxtTotaalInkomen.Text = $"{inkomen:c}";
        }

        // Void-methode met ref parameter
        private void ToonInkomen(int jaarsalaris, int jaren, ref int inkomen) 
        { 
            inkomen = jaarsalaris * jaren; 
        }

        // Function-methode die resultaat teruggeeft
        private int BerekenInkomen(int jaarsalaris, int aantalJaren)
        {
            return jaarsalaris * aantalJaren;
        }

        // Void-methode met out parameter
        private void BerekenInkomen(int jaarsalaris, int aantalJaren, out int inkomen)
        {
            inkomen = jaarsalaris * aantalJaren;
        }

        private void BtnToonInkomen_Click(object sender, RoutedEventArgs e)
        {
            // Void-methode
            int jaarsalaris = int.Parse(TxtJaarsalaris.Text);
            int aantalJaren = int.Parse(TxtAantalJaren.Text);
            ToonInkomen(jaarsalaris, aantalJaren);

            // Void-methode met ref parameter
            int inkomen1 = 0;
            ToonInkomen(jaarsalaris, aantalJaren, ref inkomen1);
            // nu is inkomen1 aangepast
            TxtTotaalInkomen.Text = $"{inkomen1:c}";

            // Function-methode die resultaat teruggeeft
            int inkomen2 = BerekenInkomen(jaarsalaris, aantalJaren);
            TxtTotaalInkomen.Text = $"{inkomen2:c}";

            // Void-methode met out parameter
            int inkomen3;
            BerekenInkomen(jaarsalaris, aantalJaren, out inkomen3);
            TxtTotaalInkomen.Text = $"{inkomen3:c}";

            TxtJaarsalaris.Focus();
        }
    }
}
