﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace CS_Oefening_030
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private string DecNaarBin(uint dec)
        {
            // Start met minstens 8 bits al voorgealloceerd
            StringBuilder builder = new StringBuilder(8);
            do
            {
                uint rest = dec % 2;
                dec /= 2;
                builder.Append(rest);
            } while (dec != 0);
            
            // Extra nullen achteraan toevoegen
            int extraNullen = 8 - (builder.Length % 8);
            extraNullen %= 8;
            for (int i = 0; i < extraNullen; i++)
                builder.Append(0);

            // Keer alles om (eerst ook alle nodige bits vooralloceren)
            // Vooralloceren (indien mogelijk) is efficienter!
            StringBuilder bin = new StringBuilder(builder.Length);
            for (int i = builder.Length - 1; i >= 0; i--)
                bin.Append(builder[i]);
           
            return bin.ToString();
        }

        private string DecNaarBinTot255(uint dec)
        {
            // Vooralloceren: We zetten de capacity van de StringBuilder op 8
            StringBuilder bin = new StringBuilder(8);
            uint deler = 128;
            for (int i = 0; i < bin.Capacity; i++)
            {
                uint bit = dec / deler;
                bin.Append(bit);
                dec %= deler; // dec = dec % deler;
                deler /= 2;
            }

            return bin.ToString();
        }

        private void BtnOmzettenTot255_Click(object sender, RoutedEventArgs e)
        {
            uint decGetal;
            bool isGelukt = uint.TryParse(TxtDec.Text, out decGetal);

            if (!isGelukt || decGetal > 255)
            {
                MessageBox.Show("Geef een getal in van 0 tot 255!", "Foutieve invoer", MessageBoxButton.OK, MessageBoxImage.Error);
                TxtDec.SelectAll();
                TxtDec.Focus();
            }
            else
            {
                TxtBin.Text = DecNaarBinTot255(decGetal);
            }
        }

        private void BtnOmzetten_Click(object sender, RoutedEventArgs e)
        {
            uint decGetal;
            bool isGelukt = uint.TryParse(TxtDec.Text, out decGetal);

            if (!isGelukt)
            {
                MessageBox.Show("Geef een natuurlijk getal in!", "Foutieve invoer", MessageBoxButton.OK, MessageBoxImage.Error);
                TxtDec.SelectAll();
                TxtDec.Focus();
            }
            else
            {
                TxtBin.Text = DecNaarBin(decGetal);
            }
        }
    }
}
