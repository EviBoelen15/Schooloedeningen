﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace CS_Sandbox_Eventprocedures
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Dictionary<Key, char> opzoekTabel = new Dictionary<Key, char>();
        public MainWindow()
        {
            InitializeComponent();
            opzoekTabel[Key.A] = 'a';
            opzoekTabel[Key.B] = 'b';
            // ...
            opzoekTabel[Key.Z] = 'z';
        }

        private void BtnKlik_Click(object sender, RoutedEventArgs e)
        {
            Button myButton = (Button)sender;
            //BtnKlik.Content = "Clicked!";
            myButton.Content = "Clicked!";
        }

        private void BtnKlik_MouseEnter(object sender, MouseEventArgs e)
        {
            Button myButton = (Button)sender;
            myButton.Content = "MouseEnter!";
        }

        private void BtnKlik_MouseLeave(object sender, MouseEventArgs e)
        {
            /*
            Button myButton = sender as Button;
            myButton.Content = "MouseLeave!";
            */
            BtnKlik.Content = "MouseLeave!";
        }

        private void TxtInput_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Return)
            {
                TxtResultaat.Text = "Enter";
            }
            else if (e.Key >= Key.A && e.Key <= Key.Z)
            {
                TxtResultaat.Text = opzoekTabel[e.Key].ToString();
            }
            else if (e.Key >= Key.NumPad0 && e.Key <= Key.NumPad9)
            {
                TxtResultaat.Text = "Numeriek";
            }
            else if (Keyboard.IsKeyDown(Key.LeftShift) || Keyboard.IsKeyDown(Key.RightShift))
            {
                TxtResultaat.Text = "Shift";
            }
        }

        private void TxtInput_KeyUp(object sender, KeyEventArgs e)
        {
            /*
            if (e.Key >= Key.A && e.Key <= Key.Z)
            {
                TxtResultaat.Text = "Letter up";
            }
            */
        }
    }
}
