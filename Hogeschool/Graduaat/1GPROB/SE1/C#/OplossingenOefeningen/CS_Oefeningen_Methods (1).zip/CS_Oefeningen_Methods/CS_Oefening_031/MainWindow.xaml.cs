﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace CS_Oefening_031
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private byte IsOndNummer(string waarde)
        {
            uint getal;

            // BE 457.033.811
            // 4570338 11

            // Foute vorm
            if (!waarde.Substring(0, 3).ToUpper().Equals("BE ") || // niet startend met "BE "
                waarde.Length != 14 || // of niet de juiste lengte
                !uint.TryParse(waarde.Substring(3).Replace(".", ""), out getal)) // of is geen getal 
            {
                return 3;
            }

            // Juiste vorm
            // Ondernemingsnummer splitsen.
            long ondNummer1 = long.Parse(getal.ToString().Substring(0, 7));
            byte ondNummer2 = byte.Parse(getal.ToString().Substring(7, 2)); // controlenummer
            //Ondernemingsnummer controleren.
            if ((97 - (ondNummer1 % 97)) == ondNummer2)
                return 1; // Juist nummer.
            else
                return 2; // Fout nummer.
        }

        private void TxtOndNr_GotFocus(object sender, RoutedEventArgs e)
        {
            TxtResultaat.Clear();
        }

        private void BtnControle_Click(object sender, RoutedEventArgs e)
        {
            byte code = IsOndNummer(TxtOndNr.Text);

            switch (code)
            {
                case 1:
                    TxtResultaat.Text = "Goed gevormd!";
                    break;
                case 2:
                    TxtResultaat.Text = "Fout nummer!";
                    MessageBox.Show("Het ondernemingsnummer is niet juist!", "Controle gegevens",
                        MessageBoxButton.OK, MessageBoxImage.Exclamation);
                    TxtOndNr.SelectAll();
                    TxtOndNr.Focus();
                    break;
                default:
                    TxtResultaat.Text = "Fout gevormd!";
                    MessageBox.Show("De vorm waarin het ondernemingsnummer moet gegeven worden is BE xxx.xxx.xxx",
                        "Controle ondernemingsnummer", MessageBoxButton.OK, MessageBoxImage.Exclamation);
                    TxtOndNr.SelectAll();
                    TxtOndNr.Focus();
                    break;
            }
        }

        private void BtnWissen_Click(object sender, RoutedEventArgs e)
        {
            TxtOndNr.Clear();
        }

        private void BtnAfsluiten_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            // Kortste manier
            MessageBoxResult resultaat = MessageBox.Show("Wens je de toepassing te sluiten?", 
                "Afsluiten van toepassing", MessageBoxButton.YesNo, MessageBoxImage.Information);
            e.Cancel = (resultaat == MessageBoxResult.No); // als er op nee gedrukt wordt => true => cancellen

            // Langere manier
            /*
            if (MessageBox.Show("Wens je de toepassing te sluiten?", "Afsluiten van toepassing", 
                MessageBoxButton.YesNo, MessageBoxImage.Information) == MessageBoxResult.Yes)
            {
                // Niet cancelen, dus Window sluiten
                e.Cancel = false;
            }
            else
            {
                // Cancelen, dus Window niet sluiten
                e.Cancel = true;
            }
            */
        }
    }
}
