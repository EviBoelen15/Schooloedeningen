﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gebouwmetlift
{
    class Gebouw
    {
        private int _aantalverdiep;
        private double _hoogtegeb, _hoogteverd, _breedteverd;

        public int Aantalverdiep
        {
            get
            {
                return _aantalverdiep;
            }
        }
        public double Hoogtegebouw
        {
            get
            {
                return _hoogtegeb;
            }

        }
        public double Hoogteverdiep
        {
            get
            {
                return _hoogteverd;
            }

        }
        public double Breedteverdiep
        {
            get
            {
                return _breedteverd;
            }

        }
        public Gebouw(int pinthoogteverdiep, int pintaantalverdiep, int pintbreedteverdiep)
        {
            _aantalverdiep = pintaantalverdiep;
            _hoogteverd = pinthoogteverdiep;
            _hoogtegeb = 400;
            _breedteverd = pintbreedteverdiep;
        }
   }
}
