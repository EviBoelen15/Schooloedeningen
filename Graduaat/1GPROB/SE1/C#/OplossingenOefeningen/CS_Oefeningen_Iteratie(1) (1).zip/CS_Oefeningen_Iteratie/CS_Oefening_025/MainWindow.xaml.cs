﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace CS_Oefening_025
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void BtnBerekenen_Click(object sender, RoutedEventArgs e)
        {
            decimal kapitaal = 0.0M;
            decimal gewenstEindKapitaal = 0.0M;
            decimal interestVoet = 0.0M;
            bool isMislukt = !decimal.TryParse(TxtBeginKapitaal.Text, out kapitaal) ||
                !decimal.TryParse(TxtGewenstEindKapitaal.Text, out gewenstEindKapitaal) ||
                !decimal.TryParse(TxtInterestVoet.Text, out interestVoet);

            if (isMislukt)
            {
                BtnWissen_Click(this, null);
                return;
            }

            if (kapitaal >= gewenstEindKapitaal)
            {
                TxtResultaat.Text = $"Waarde na 0 jaren: {kapitaal}";
                return;
            }

            int aantalJaar = 0;

            StringBuilder stb = new StringBuilder();
            do
            {
                aantalJaar++;
                kapitaal *= (1.0M + (interestVoet / 100.0M)); // kapitaal += (interestVoet / 100.0M) * kapitaal;
                stb.AppendLine($"Waarde na {aantalJaar, 2} jaren: {kapitaal}");
            } while (kapitaal < gewenstEindKapitaal);
            TxtResultaat.Text = stb.ToString();
        }

        private void BtnWissen_Click(object sender, RoutedEventArgs e)
        {
            TxtBeginKapitaal.Clear();
            TxtGewenstEindKapitaal.Clear();
            TxtInterestVoet.Clear();
            TxtResultaat.Clear();
            TxtBeginKapitaal.Focus();
        }

        private void BtnAfsluiten_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
