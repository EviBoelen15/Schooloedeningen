﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

using Microsoft.VisualBasic;

namespace CS_Oefening_027
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }


        private void BtnStart_Click(object sender, RoutedEventArgs e)
        {
            Random rnd = new Random();
            int randomGetal = rnd.Next(0, 101);
            int aantalBeurten = 0;
            int geraden = -1;

            string antwoord = Interaction.InputBox("Geef een getal tussen 0 en 100", "Raadspel", "50");
            
            // Testen tot er een (juiste) invoer is.
            while (geraden != randomGetal)
            {
                aantalBeurten++;
                if (string.IsNullOrEmpty(antwoord) || !int.TryParse(antwoord, out geraden))
                {
                    MessageBox.Show("Geef een getal in", "Foutieve invoer", MessageBoxButton.OK, MessageBoxImage.Exclamation);
                }
                else if (geraden < randomGetal)
                {
                    MessageBox.Show("Raad hoger!", "Raadspel");
                }
                else
                {
                    MessageBox.Show("Raad lager!", "Raadspel");
                }

                antwoord = Interaction.InputBox("Geef een getal tussen 0 en 100", "Raadspel", "50");
            }

            MessageBox.Show($"U heeft het getal geraden in {aantalBeurten} beurten.", "Proficiat!");
        }

        private void BtnSluiten_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
