﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace CS_Oefening_022
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private Random rnd = new Random();
        private StringBuilder builder = new StringBuilder();

        public MainWindow()
        {
            InitializeComponent();
        }

        private void BtnStart_Click(object sender, RoutedEventArgs e)
        {
            /*
            TxtResultaat.Clear();
            const int teGooien = 6;
            int gegooid = 0;
            int i = 0;
            while (gegooid != teGooien)
            {
                gegooid = rnd.Next(1, 7); // getal van 1 tot en met 6
                i++;
                TxtResultaat.Text += $"Worp {i,2} geeft {gegooid}\r\n";
            }
            */
            builder.Clear();
            const int teGooien = 6;
            int gegooid = 0;
            int i = 0;
            do
            {
                gegooid = rnd.Next(1, 7); // getal van 1 tot en met 6
                i++;
                builder.AppendLine($"Worp {i,2} geeft {gegooid}");

            } while (gegooid != teGooien);
            TxtResultaat.Text = builder.ToString();
        }

        private void BtnOpnieuw_Click(object sender, RoutedEventArgs e)
        {
            TxtResultaat.Clear();
            BtnStart.Focus();
        }

        private void BtnSluiten_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
