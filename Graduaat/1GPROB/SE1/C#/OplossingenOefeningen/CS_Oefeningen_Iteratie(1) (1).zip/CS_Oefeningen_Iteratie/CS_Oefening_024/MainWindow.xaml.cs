﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace CS_Oefening_024
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void BtnBerekenen_Click(object sender, RoutedEventArgs e)
        {
            decimal weekgeld = 0.0M;
            decimal wekelijkseVerhoging = 0.0M;
            decimal gewenstBedrag = 0.0M;

            bool isMislukt = !decimal.TryParse(TxtWeekgeld.Text, out weekgeld) ||
                !decimal.TryParse(TxtWekelijkseVerhoging.Text, out wekelijkseVerhoging) ||
                !decimal.TryParse(TxtGewenstBedrag.Text, out gewenstBedrag);

            /*
            bool isGelukt = decimal.TryParse(TxtWeekgeld.Text, out weekgeld) &&
                decimal.TryParse(TxtWekelijkseVerhoging.Text, out wekelijkseVerhoging) &&
                decimal.TryParse(TxtGewenstBedrag.Text, out gewenstBedrag);
            */

            if (isMislukt)
            {
                BtnWissen_Click(this, null);
                return;
            }

            decimal spaargeld = 0.0M;
            decimal extraWeekgeld = 0.0M;
            decimal totaalSpaargeld = 0.0M;
            int aantalWeken = 0;
            do
            {
                spaargeld += weekgeld;
                extraWeekgeld += wekelijkseVerhoging;
                totaalSpaargeld = spaargeld + extraWeekgeld;
                aantalWeken++;
            } while (totaalSpaargeld < gewenstBedrag);

            TxtResultaat.Text = $"Spaarbedrag na {aantalWeken} weken: {spaargeld:c}\r\n\r\n" +
                $"Extra weekgeld op dat moment: {extraWeekgeld:c}\r\n\r\n" +
                $"Totaal spaargeld: {totaalSpaargeld:c}";
        }

        private void BtnWissen_Click(object sender, RoutedEventArgs e)
        {
            TxtWeekgeld.Clear();
            TxtWekelijkseVerhoging.Clear();
            TxtGewenstBedrag.Clear();
            TxtResultaat.Clear();

            TxtWeekgeld.Focus();
        }

        private void BtnAfsluiten_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
