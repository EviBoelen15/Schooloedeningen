﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

using Microsoft.VisualBasic;

namespace CS_Oefening_027
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void BtnStart_Click(object sender, RoutedEventArgs e)
        {
            Random rnd = new Random();
            int randomGetal = rnd.Next(0, 101);
            int aantalBeurten = 0;
            int geraden = -1;

            while (geraden != randomGetal)
            {
                aantalBeurten++;
            }

            string antwoord = Interaction.InputBox("Geef een getal", "Invoer", "50", 500);
            // Testen tot ereen invoer is.while(string.IsNullOrEmpty(antwoord))  // Cancel, Sluiten of lege string{MessageBox.Show("Geef een getal in", "Foutieve invoer", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);antwoord = Interaction.InputBox("Geef een getal", "Invoer", "50", 500);};

        }

        private void BtnSluiten_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}
