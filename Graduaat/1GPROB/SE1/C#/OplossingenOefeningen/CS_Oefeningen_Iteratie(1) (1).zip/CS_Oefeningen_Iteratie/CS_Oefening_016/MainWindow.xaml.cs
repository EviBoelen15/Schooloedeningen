﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace CS_Oefening_016
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void BtnBerekenen_Click(object sender, RoutedEventArgs e)
        {
            // Getal uitlezen van textbox. Als dit niet lukt (geen getal is), 
            // dan niets doen (return => weggaan uit BtnBerekenen_Click)
            ulong getal;
            bool isGelukt = ulong.TryParse(TxtGetal.Text, out getal);
            if (!isGelukt || getal > 84)
            {
                return;
            }
            // Maak de TxtResultaat textbox weer leeg
            TxtResultaat.Text = string.Empty;

            const int aantalMachten = 10;
            ulong macht = 1;
            for (int i = 1; i <= aantalMachten; i++)
            {
                macht *= getal; //macht = macht * getal;
                TxtResultaat.Text += $"Macht {i:d2} van {getal} is {macht}\r\n";
            }
        }

        private void BtnWissen_Click(object sender, RoutedEventArgs e)
        {
            TxtGetal.Text = string.Empty;
            TxtResultaat.Text = string.Empty;
        }

        private void BtnAfsluiten_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
