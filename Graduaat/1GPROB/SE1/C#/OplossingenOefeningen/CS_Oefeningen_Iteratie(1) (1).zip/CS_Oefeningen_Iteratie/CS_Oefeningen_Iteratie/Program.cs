﻿using System;

namespace CS_Oefeningen_Iteratie
{
    class Program
    {
        public static void TestPassByValue(int getal)
        {
            Console.WriteLine($"Waarde in method voor wijziging: {getal}");
            getal += 10;
            Console.WriteLine($"Waarde in method na wijziging: {getal}");
        }

        public static void TestPassByReference(ref int getal)
        {
            Console.WriteLine($"Waarde in method voor wijziging: {getal}");
            getal += 10;
            Console.WriteLine($"Waarde in method na wijziging: {getal}");
        }

        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
            int getalleke = 0;

            //TestPassByValue(getalleke);
            TestPassByReference(ref getalleke);
            Console.WriteLine($"Waarde na methodoproep: {getalleke}");

            Console.ReadLine();
        }
    }
}
