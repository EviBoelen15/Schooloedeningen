﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace CS_Oefening_018
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private Random rnd = new Random();

        public MainWindow()
        {
            InitializeComponent();
        }

        private void BtnStart_Click(object sender, RoutedEventArgs e)
        {
            // Eerst resultaat textbox leegmaken
            TxtResultaat.Text = string.Empty;

            const int aantalLottoGetallen = 6;
            const int minLottoGetal = 1;
            const int maxLottoGetal = 45;
            
            for (int i = 1; i <= aantalLottoGetallen; i++)
            {
                int lottoGetal = rnd.Next(minLottoGetal, maxLottoGetal + 1);
                TxtResultaat.Text += $"Getal {i}: {lottoGetal}\r\n";
            }
        }

        private void BtnWissen_Click(object sender, RoutedEventArgs e)
        {
            TxtResultaat.Clear();
            //TxtResultaat.Text = string.Empty;
        }

        private void BtnAfsluiten_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
