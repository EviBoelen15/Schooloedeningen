﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace CS_Oefening_023
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void BtnBerekenen_Click(object sender, RoutedEventArgs e)
        {
            double bevolking = double.Parse(TxtHuidigeBevolking.Text);
            double dubbeleBevolking = 2.0 * bevolking;
            int aantalJaren = 0;

            // 1,1% => groeiPercentage 1.1/100 = 0.011 + 1.0
            // 101,1% => 1.0 + (0.011 / 100.0)
            double groeiPercentage = double.Parse(TxtGroeipercentage.Text);
            double groeiFactor = (1.0 + (groeiPercentage/ 100.0));

            do
            {
                bevolking *= groeiFactor;
                aantalJaren++;
            } while (bevolking < dubbeleBevolking);

            TxtResultaat.Text = $"Verdubbeling bevolking in {TxtLand.Text} na {aantalJaren}\r\n\r\n" + 
                $"Nieuw bevolkingsaantal op dat moment: {bevolking:F3}";
        }

        private void BtnWissen_Click(object sender, RoutedEventArgs e)
        {
            TxtLand.Clear();
            TxtHuidigeBevolking.Clear();
            TxtGroeipercentage.Clear();
            TxtResultaat.Clear();
            
            TxtLand.Focus();
        }

        private void BtnAfsluiten_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
