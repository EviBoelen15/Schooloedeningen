﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace CS_Oefening_021
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        // Gebruik: using System.Windows.Threading; bovenaan
        private DispatcherTimer klokje = new DispatcherTimer();

        public MainWindow()
        {
            InitializeComponent();

            LblFoutmelding.Visibility = Visibility.Hidden;

            // Timer laten aflopen om de 1 seconde.     
            klokje.Interval = new TimeSpan(0, 0, 1); // hoe snel tikt de klok
            klokje.Tick += new EventHandler(Wekker_Tick); // wat doen na tik van de klok
        }

        private void Wekker_Tick(object sender, EventArgs e)
        {
            // Als foutmelding zichtbaar is: maak hidden en anders zichtbaar maken
            LblFoutmelding.Visibility = LblFoutmelding.IsVisible ? Visibility.Hidden : Visibility.Visible;

            /*
            if (LblFoutmelding.IsVisible)
            {
                LblFoutmelding.Visibility = Visibility.Hidden;
            }
            else
            {
                LblFoutmelding.Visibility = Visibility.Visible;
            }
            */
        }

        private void BtnOptellen_Click(object sender, RoutedEventArgs e)
        {
            int maxWaarde;
            bool isGeldigGetal = int.TryParse(TxtMaxWaarde.Text, out maxWaarde);
            if (!isGeldigGetal || maxWaarde > 20 || maxWaarde < 1)
            {
                // Foute invoer: 
                // Alles leegmaken
                TxtResultaat.Clear();
                TxtMaxWaarde.Clear();
                TxtMaxWaarde.Focus();

                // Foute invoer: 
                // Timer inschakelen (om label te kunnen laten flikkeren)
                klokje.IsEnabled = true;
                
                return;
            }

            // Goede invoer: Timer uitschakelen en label verbergen.
            klokje.IsEnabled = false;
            LblFoutmelding.Visibility = Visibility.Hidden;

            StringBuilder resultaat = new StringBuilder();
            // Rijhoofding
            resultaat.Append("\t");
            for (int i = 1; i <= maxWaarde; i++)
            {
                resultaat.Append($"{i}\t");
            }
            resultaat.AppendLine().AppendLine(); // 2 regels open laten

            // Loop over de rijen
            for (int i = 1; i <= maxWaarde; i++)
            {
                resultaat.Append($"{i}\t");
                // Loop over de kolommen
                for (int j = 1; j <= maxWaarde; j++)
                {
                    resultaat.Append($"{i + j}\t");
                }
                resultaat.AppendLine(); // nieuwe rij starten
            }

            TxtResultaat.Text = resultaat.ToString();
        }

        private void BtnVermenigvuldigen_Click(object sender, RoutedEventArgs e)
        {
            // Exact hetzelfde als Optellen, alleen * gebruiken:
            //resultaat.Append($"{i * j}\t");

            // Hierin zit dus heel veel gecopy-paste code...
            // We zouden een manier willen vinden om dit te vermijden
            // Zie syllabus hoofdstuk 7 in een latere les
        }

        private void BtnWissen_Click(object sender, RoutedEventArgs e)
        {
            TxtResultaat.Clear();
            TxtMaxWaarde.Clear();
            TxtMaxWaarde.Focus();
        }

        private void BtnSluiten_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
