﻿using System;
using System.Text;

namespace CS_Console_Sandbox_Hoofdstuk_06
{
    class Program
    {
        static void Main(string[] args)
        {
            // System.Math

            // Math.PI
            float straal = 0.5f;
            float omtrek = 2 * (float)Math.PI * straal;

            // Math.E


            // Absolute waarde berekenen
            double getal = Math.Abs(-12.34);

            // Minimum en maximum van getallen bepalen
            getal = Math.Min(-12.34, 10);
            getal = Math.Max(-12.34, 10);

            // Afronden naar het dichtsbijzijnde getal:
            getal = Math.Round(10.5);
            getal = Math.Round(10.51);
            getal = Math.Round(11.5);
            getal = Math.Round(-12.51);
            getal = Math.Round(-12.3456, 2);

            // Afronden naar boven:
            getal = Math.Ceiling(11.5); // 12
            getal = Math.Ceiling(-11.5); // -11

            // Afronden naar beneden:
            getal = Math.Floor(11.5); // 11
            getal = Math.Floor(-11.5); // -12

            getal = Math.Pow(2, 3); // 2^3 = 2*2*2 = 8
            getal = Math.Log(8, 2); // 2^getal = 8 ==> getal == 3
            getal = Math.Sqrt(16); // 4



            // System.String
            // Is een string leeg?
            string str = "Visual CSharp";
            if (str.Length == 0)
            {
                Console.WriteLine("Is leeg");
            }

            // Strings vergelijken
            bool isGelijk = str.Equals("blabla");
            isGelijk = str.Equals("Visual CSharp");
            isGelijk = str.Equals("viSual cshArp", StringComparison.OrdinalIgnoreCase);

            // String functies
            int resultaat = string.Compare("aa", "AA");
            resultaat = string.Compare("Blabla", "blabla");
            resultaat = string.Compare("Blabla", "blabla", true);

            // beide strings gelijk: 0 teruggeven
            // linkse string kleiner (alfabetisch gezien) dan rechtse: -1
            // linkse groter (alfabetisch gezien) is dan de rechtse: 1

            // String methods
            str = "Visual CSharp";
            string substr = str.Substring(2);
            substr = str.Substring(2, 5);

            string padded = "Visual CSharp".PadLeft(20);
            padded = "Visual CSharp".PadRight(20);
            padded = "Visual CSharp".PadLeft(20, '*');
            padded = "Visual CSharp".PadRight(20, '*');


            int index = "Visual CSharp".IndexOf("CSh");


            // StringBuilder
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("Nieuwe tekst:");
            sb.Append("Punt: ").Append(" 10").AppendLine();
            sb.AppendLine();
            string resultaatStr = sb.ToString();


            // Random
            Random rnd = new Random();

            for (int i = 0; i < 10; i++)
            {
                Console.WriteLine(rnd.Next(1, 7));

            }

            // DateTime
            DateTime datum = DateTime.Now;
            string datumString = datum.ToShortDateString();

            char kar = '9';
            double getalleke = char.GetNumericValue(kar);

            string karakterString = "S";
            char karakter = char.Parse(karakterString);


            Console.ReadLine();
        }
    }
}
