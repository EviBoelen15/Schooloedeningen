﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace CS_Oefening_008
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void ButtonBerekenen_Click(object sender, RoutedEventArgs e)
        {
            // Declaratie van variabelen die we later gebruiken    
            float bruto, belasting, netto;

            // Toekenning aan variabele naam.     
            string naam = TxtPersoneelslid.Text;
            float uurloon = float.Parse(TxtUurloon.Text);
            short aantalUren = short.Parse(TxtAantalUren.Text);

            // Berekening     
            bruto = aantalUren * uurloon;

            // Belastingsschijven If-structuur     
            if (bruto <= 10000)
            {
                // Als je bruto niet meer dan 10000 euro verdient, 0 euro belasting.
                belasting = 0;
            }
            else if (bruto <= 15000)
            {
                belasting = (bruto - 10000) * 0.2f;
            }
            else if (bruto <= 25000)
            {
                belasting = ((bruto - 15000) * 0.3f) + 1000;
            }
            else if (bruto <= 50000)
            {
                belasting = ((bruto - 25000) * 0.4f) + 4000;
            }
            else
            {
                belasting = ((bruto - 50000) * 0.5f) + 14000;
            }

            netto = bruto - belasting;

            // Afdruk met interpolation string of $-string     
            TxtResultaat.Text = $"LOONFICHE VAN {naam}\r\n\r\n" +
                $"Aantal gewerkte uren : {aantalUren}\r\n" +
                $"Uurloon : {uurloon:c}\r\n" +
                $"Brutojaarwedde : {bruto:C}\r\n" +
                $"Belasting : {belasting:C} \r\nNettojaarwedde : {netto:c}";
        }

        private void ButtonWissen_Click(object sender, RoutedEventArgs e)
        {
            TxtPersoneelslid.Text = string.Empty;
            TxtAantalUren.Text = "0";
            TxtUurloon.Text = "0";
            TxtResultaat.Text = string.Empty;

            TxtPersoneelslid.Focus();
        }

        private void ButtonAfsluiten_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
