﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace CS_Oefeningen_005
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void ButtonBerekenen_Click(object sender, RoutedEventArgs e)
        {     
            // Declaratie van variabelen.     
            short aantalNormaal, aantalKorting, aantalStudenten;     
            float totaal;     
            const float prijsNormaal = 9.10f;     
            const float prijsKorting = 8.10f;     
            const float prijsStudent = 6.90f; 

            // Gegevens opvragen.     
            aantalNormaal = short.Parse(TxtNormaal.Text);     
            aantalKorting = short.Parse(TxtKorting.Text);     
            aantalStudenten = short.Parse(TxtStudent.Text); 

            // Ticketprijs berekenen.     
            totaal = (aantalNormaal * prijsNormaal) + 
                (aantalKorting * prijsKorting) + 
                (aantalStudenten * prijsStudent); 

            // Afdrukken.      
            TxtPrijs.Text = totaal.ToString(); // Convert.ToString(totaal);
        } 

        private void ButtonAfsluiten_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void ButtonWissen_Click(object sender, RoutedEventArgs e)
        { 
            TxtKorting.Text = "0";
            TxtNormaal.Text = "0";
            TxtStudent.Text = "0";
            TxtPrijs.Text = string.Empty;
        }
    }
}
