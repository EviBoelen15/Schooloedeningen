Open het .sln bestand (Solution):
CS_Oefeningen_Basis_Selectie.sln

In Visual Studio:
* Rechterklik op een project dat je wil uitvoeren.
* Set as Startup Project
* Compile en run dit project door op de groene pijl vanboven te drukken.