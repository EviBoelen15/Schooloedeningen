﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace CS_Oefeningen_Basis_Selectie
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void BtnBerekenen_Click(object sender, RoutedEventArgs e)
        {
            string tekst = TxtEuro.Text;
            int getal = Convert.ToInt32(tekst);
            char karakter = 'c';
            switch (getal)
            {
                case 10:
                    TxtBef.Text = "Dit is 10";
                    break;
                case 15:
                    TxtBef.Text = "Dit is 15";
                    break;
                case 16:
                case 17:
                case 18:
                    TxtBef.Text = "Dit is 16, 17 of 18";
                    break;
                default:
                    TxtBef.Text = "Iets anders";
                    break;
            }
            bool conditie = getal == 10;

            if (conditie || getal < 3)
            {
                if (karakter == 'c')
                {

                }
            } 
            else if (getal == 15)
            {

            }
            else if (getal == 16 || getal == 17 || getal == 18)
            {

            }
            else
            {

            }


            /*float euroBedrag = Convert.ToSingle(tekst);
            float frank = euroBedrag * 40.3399f;
            TxtBef.Text = Convert.ToString(frank);*/
        }

        private void BtnWissen_Click(object sender, RoutedEventArgs e)
        {
            // Inhoud wordt gewist met lege tekst:    
            // TxtBef.Text = "";           
            // Duidelijker wat er bedoeld is:

            TxtBef.Text = "";   
            TxtEuro.Text = "0";
        }
    }
}
