﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace CS_Oefening_007
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            LblVluchtklasse.Visibility = Visibility.Hidden;
        }

        private void BtnBerekenen_Click(object sender, RoutedEventArgs e)
        {     
            //Declaratie variabelen     
            float totVluchtprijs;     
            float totVerblijfprijs;     
            float totReisprijs;     
            float korting;     
            float teBetalen; 

            //Berekening prijzen
            totVluchtprijs = float.Parse(TxtBasisvlucht.Text) * 
                float.Parse(TxtAantalPersonen.Text);

            totVerblijfprijs = float.Parse(TxtBasisprijs.Text) * 
                (float.Parse(TxtAantalDagen.Text)) * 
                float.Parse(TxtAantalPersonen.Text);
            totReisprijs = totVluchtprijs + totVerblijfprijs;
            float kortingspercentage = float.Parse(TxtKortingspercentage.Text);

            korting = totReisprijs * kortingspercentage / 100;     
            teBetalen = totReisprijs - korting;

            // Afdruk
            // c: currency (munteenheid)
            TxtResultaat.Text =
                $"REISKOST VOLGENS BESTELLING NAAR {TxtBestemming.Text} \r\n\r\n" +
                $"Totale vluchtprijs: {totVluchtprijs:c} \r\nTotale verblijfsprijs: {totVerblijfprijs:c} \r\n" +     
                $"Totale reisprijs: {totReisprijs:c} \r\nKorting: {korting:c} \r\n\r\n" +     
                $"Te betalen : {teBetalen:c}";
        }

        private void BtnWissen_Click(object sender, RoutedEventArgs e)
        {             
            TxtBasisvlucht.Text = "0";         
            TxtBestemming.Clear();
            TxtBestemming.Text = ""; // string.Empty
            TxtVluchtklasse.Text = "2";         
            TxtBasisprijs.Text = "0";         
            TxtAantalDagen.Text = "1";         
            TxtAantalPersonen.Text = "1";         
            TxtKortingspercentage.Text = "0";         
            TxtResultaat.Clear();         
            // Focus geven aan tekstvak.         
            TxtBestemming.Focus(); 
        } 

        private void BtnAfsluiten_Click(object sender, RoutedEventArgs e) 
        { 
            Close(); 
        }

        private void TxtVluchtklasse_GotFocus(object sender, RoutedEventArgs e) 
        { 
            LblVluchtklasse.Visibility = Visibility.Visible; 
        }

        private void TxtVluchtklasse_LostFocus(object sender, RoutedEventArgs e) 
        { 
            LblVluchtklasse.Visibility = Visibility.Hidden; 
        }

    }
}
