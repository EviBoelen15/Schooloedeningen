﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace CS_Oefening_002
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void BtnBereken_Click(object sender, RoutedEventArgs e)
        {
            // Omtrek berekenen.
            string straaltekst = TxtStraal.Text;

            float straal = Convert.ToSingle(straaltekst);
            float omtrek = 2.0f * (float)Math.PI * straal;
            TxtOmtrek.Text = Convert.ToString(omtrek);

            // Oppervlakte berekenen.
            float oppervlakte = (float)(Math.PI * Math.Pow(straal, 2));
            TxtOppervlakte.Text = Convert.ToString(oppervlakte);   

            // Focus naar object verplaatsen.
            BtnWissen.Focus();
        }

        private void BtnWissen_Click(object sender, RoutedEventArgs e)
        {
            TxtStraal.Text = "0"; 
            TxtOmtrek.Text = "0"; 
            TxtOppervlakte.Text = "0";

            // Focus naar object verplaatsen.
            TxtStraal.Focus();
        }
    }
}
