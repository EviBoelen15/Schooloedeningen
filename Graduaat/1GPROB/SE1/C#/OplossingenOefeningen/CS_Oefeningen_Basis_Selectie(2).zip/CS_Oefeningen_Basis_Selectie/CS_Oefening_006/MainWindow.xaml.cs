﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace CS_Oefening_006
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void BtnBerekenen_Click(object sender, RoutedEventArgs e)
        {
            // Declaratie van variabelen     
            float bruto, belasting, netto, uurloon;
            short aantalUren;

            // Declaratie constante     
            const float belastingPercentage = 0.3f;

            // Toekenning aan variabele naam.     
            string naam = TxtPersoneelslid.Text;
            uurloon = float.Parse(TxtUurloon.Text);
            aantalUren = short.Parse(TxtAantalUren.Text);
            // OF: aantalUren = Convert.ToInt16(TxtAantalUren.Text); 

            // Berekening     
            bruto = aantalUren * uurloon;
            belasting = bruto * belastingPercentage;
            netto = bruto - belasting;

            // Afdruk met interpolation string of $-string
            // {variabele naam} om waarde van variabele in string te zetten
            // \r\n is 1 nieuwe regel
            // + om te strings aan elkaar te plakken
            TxtResultaat.Text = $"LOONFICHE VAN {naam}\r\n\r\n" +
                $"Aantal gewerkte uren : {aantalUren}\r\n" +
                $"Uurloon : {uurloon:c}\r\n" +
                $"Brutojaarwedde : {bruto:C}\r\n" +
                $"Belasting : {belasting:C} \r\nNettojaarwedde : {netto:c}";
        }

        private void BtnWissen_Click(object sender, RoutedEventArgs e)
        {   
            TxtPersoneelslid.Clear();
            TxtAantalUren.Text = "0";
            TxtUurloon.Text = "0";
            TxtResultaat.Text = string.Empty;
    
            TxtPersoneelslid.Focus();
        }

        private void BtnAfsluiten_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
