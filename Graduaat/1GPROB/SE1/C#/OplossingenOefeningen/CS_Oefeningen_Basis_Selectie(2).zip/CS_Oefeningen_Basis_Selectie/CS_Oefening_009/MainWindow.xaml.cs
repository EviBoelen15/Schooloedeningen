﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace CS_Oefening_009
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        // Zet variabelen hier als je die nodig hebt over meerdere functies
        private int jaar; 
        
        public MainWindow()
        {
            InitializeComponent();
        }

        private void BtnNumeriek_Click(object sender, RoutedEventArgs e)
        {
            // Resultaat wordt geschreven in jaar variabele.
            // TryParse geeft een bool terug (true als het de tekst kan omzetten naarint, 
            // false als dit niet gaat)
            bool isNumeriek = int.TryParse(TxtJaar.Text, out jaar);


            if (isNumeriek) 
            { 
                LblNumeriek.Content = "Is numeriek"; 
                // Indien numeriek, dan kunnen we berekenen
                BtnBerekenen.IsEnabled = true; 
            } 
            else 
            { 
                LblNumeriek.Content = "Geef een correct jaartal!";
                BtnBerekenen.IsEnabled = false;
            }

            // Verleg de focus naar de BtnBerekenen button
            BtnBerekenen.Focus();
        }

        private void BtnBerekenen_Click(object sender, RoutedEventArgs e)
        {
            const float prijsPerStudiepunt = 15.65f;
            int aantalSP = int.Parse(TxtAantalStudiepunten.Text);

            // Opnieuw het jaar opvragen omdat het gewijzigd kan zijn.      
            bool isNumeriek = int.TryParse(TxtJaar.Text, out jaar);

            // Schrikkeljaar: jaar dat deelbaar is door 4 en geen vol eeuwjaar, 
            // of als het een eeuwjaar is dan moet het deelbaar zijn door 400.     
            // Dit betekent dat 1900 en 2100 geen schrikkeljaren zijn (volle eeuwjaren) en het jaar 2000 wel (deelbaar door 400). 
  
            if (isNumeriek)
            {
                // Test op schrikkeljaar     
                // * Jaar deelbaar door 4 EN geen eeuwjaar (niet deelbaar door honderd)
                // * OF een jaar is deelbaar door 400
                if ((jaar % 4 == 0 && jaar % 100 != 0) || (jaar % 400 == 0))
                {
                    LblSchrikkeljaar.Content = "Is een schrikkeljaar";
                    // Schrikkeljaar, dus 8 extra studiepunten
                    float inschrijvingsGeld = ((aantalSP + 8) * prijsPerStudiepunt);
                    TxtInschrijvingsgeld.Text = inschrijvingsGeld.ToString();
                }
                else
                {
                    LblSchrikkeljaar.Content = "Is geen schrikkeljaar";
                    // Geen schrikkeljaar, dus geen extra studiepunten
                    TxtInschrijvingsgeld.Text = (aantalSP * prijsPerStudiepunt).ToString();
                }
            }

            TxtJaar.Focus();
        }

        private void BtnAfsluiten_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
