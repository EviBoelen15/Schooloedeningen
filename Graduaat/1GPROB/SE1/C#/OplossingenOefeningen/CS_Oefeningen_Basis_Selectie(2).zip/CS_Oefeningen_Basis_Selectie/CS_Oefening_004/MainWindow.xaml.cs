﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace CS_Oefening_004
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void BtnControle_Click(object sender, RoutedEventArgs e)
        {
            const int getal = 97;
            int ondernemingsnummer = int.Parse(TxtOndNr1.Text);
            // int ondernemingsnummer = Convert.ToInt32(TxtOndNr1.Text);
            int resultaat = getal - (ondernemingsnummer % getal);

            TxtOndNr2.Text = Convert.ToString( resultaat);
        }

        private void BtnBereken_Click(object sender, RoutedEventArgs e)
        {
            // Declaratie variabelen.     
            float prijs, teBetalen;
            int aantal;

            // De gebruiker geeft de prijs en het aantal stuks in.  
            // prijs = Convert.ToSingle(TxtPrijs.Text); 
            prijs = float.Parse(TxtPrijs.Text);
            aantal = int.Parse(TxtAantal.Text);

            // Berekenen van het te betalen bedrag.     
            teBetalen = prijs * aantal;

            // Tonen van het te betalen bedrag.
            TxtTeBetalen.Text = teBetalen.ToString();

            BtnWissen.Focus();
        }

        public void BtnWissen_Click(object sender, RoutedEventArgs e)
        {
            TxtAantal.Text = string.Empty;
            TxtPrijs.Text = "";
            TxtTeBetalen.Text = string.Empty;
            TxtOndNr1.Clear();
            TxtOndNr2.Clear();

            TxtPrijs.Focus();
        }

        public void BtnSluiten_Click(object sender, RoutedEventArgs e)
        {       
            // Formulier sluiten.       
            Close();
        }
    }
}
