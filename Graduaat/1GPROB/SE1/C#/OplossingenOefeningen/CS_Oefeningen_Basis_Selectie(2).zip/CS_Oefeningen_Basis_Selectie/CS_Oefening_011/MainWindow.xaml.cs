﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace CS_Oefening_011
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        // Tip: Random number generator
        // private Random rnd = new Random();
        // int randomGetal = rnd.Next(1, 101); // van 1 tot 100 (101 telt niet mee)

        private int teRadenGetal;
        private int aantalPogingen = 0;
        // Random number generator
        private Random rnd = new Random();

        public MainWindow()
        {
            InitializeComponent();
            teRadenGetal = int.Parse(TxtGetal.Text);
        }

        private void BtnEvalueer_Click(object sender, RoutedEventArgs e)
        {
            // Extra poging gewaagd
            aantalPogingen++;
            // aantalPogingen = aantalPogingen + 1;
            // aantalPogingen += 1;

            // Ingevoerd getal declareren en converteren naar getal.
            bool getalIsIngegeven = short.TryParse(TxtGetal.Text, out short ingegevenGetal);

            if (getalIsIngegeven)
            {

                // Controle naar geraden getal.
                if (ingegevenGetal == teRadenGetal)
                {
                    TxtInfo.Text = "Proficiat! U hebt het getal geraden!";
                    TxtAantalKeren.Text = $"Aantal keren geraden: {aantalPogingen}\r\n\r\n";
                }
                else if (teRadenGetal < ingegevenGetal)
                {
                    TxtInfo.Text = "Raad lager!";
                }
                else
                {
                    TxtInfo.Text = "Raad hoger!";
                }
            }
            //Tekst automatisch selecteren en focus daarop zetten
            TxtGetal.SelectAll();
            TxtGetal.Focus();
        }

        private void BtnNieuw_Click(object sender, RoutedEventArgs e)
        {
            aantalPogingen = 0; 
            teRadenGetal = rnd.Next(1, 101); // Genereer nieuw getal tussen 1 en 100 (101 telt niet mee)
            TxtGetal.Clear(); 
            TxtInfo.Clear(); 
            TxtAantalKeren.Clear(); 
            
            TxtGetal.Focus();
        }

        private void BtnEinde_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
