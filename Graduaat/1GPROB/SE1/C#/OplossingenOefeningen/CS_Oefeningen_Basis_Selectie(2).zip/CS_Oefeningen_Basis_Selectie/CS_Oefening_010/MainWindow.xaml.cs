﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace CS_Oefening_010
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            LblVluchtklasse.Visibility = Visibility.Hidden;
        }

        private void BtnBerekenen_Click(object sender, RoutedEventArgs e)
        {         
            // Declaratie variabelen         
            float vluchtprijs, verblijfsprijs, reisprijs;
            float teBetalen;

            // Test of vereiste gegevens correct ingevuld zijn
  
            bool testBasis = float.TryParse(TxtBasisprijs.Text, out float dagprijs);     
            bool testVlucht = float.TryParse(TxtBasisvlucht.Text, out float basisVluchtprijs);     
            bool testPersonen = int.TryParse(TxtAantalPersonen.Text, out int aantalPersonen);     
            bool testDagen = int.TryParse(TxtAantalDagen.Text, out int aantalDagen);     
            bool testKorting = float.TryParse(TxtKortingspercentage.Text, out float korting);
            bool testVluchtklasse = int.TryParse(TxtVluchtklasse.Text, out int vluchtklasse);
           
            // NIEUW in deze oefening:
            // MessageBox tonen als één van de gegevens ontbreekt. (if)
            // Anders: doe de berekeningen (else)        
            if (!testBasis || !testVlucht|| !testPersonen || !testDagen || !testKorting || !testVluchtklasse)         
            {             
                MessageBox.Show("Niet alle gegevens zijn correct ingevuld!", 
                    "Ontbrekende gegevens.", 
                    MessageBoxButton.OK,
                    MessageBoxImage.Stop);         
            }
            else
            {             
                // Berekening prijzen als alle gegevens zijn ingevuld         
                vluchtprijs = basisVluchtprijs * aantalPersonen;             
                switch (vluchtklasse)             
                {                 
                    case 1:
                        //vluchtprijs = vluchtprijs * 1.3f;
                        vluchtprijs *= 1.3f; // vluchtprijs 30% verhoogd
                        break;                 
                    case 3:                     
                        vluchtprijs *= 0.8f; // vluchtprijs 20% verlaagd                    
                        break;     
                  // geen case 2 nodig, want voor vluchtklasse 2 blijft de vluchtprijs hetzelfde
                } 

                switch (aantalPersonen)
                {
                    case 0:
                    case 1: 
                    case 2: 
                        verblijfsprijs = dagprijs * aantalDagen * aantalPersonen; 
                        break;
                    case 3: 
                        // Vanaf 3de persoon: ipv. maal 3 personen nu voor de laatste persoon 50% goedkoper
                        // Dus maal 2,5 persoon in feite.
                        verblijfsprijs = dagprijs * aantalDagen * 2.5f; 
                        break;
                    default:
                        // Meer dan 3 personen
                        verblijfsprijs = dagprijs * aantalDagen * 2.5f;  // 3 personen 
                        // Tel hier nog bij: de overige personen (aantalPersonen - 3 eerste)
                        // De overige personen krijgen daling van 70%, dus moeten maar 30% betalen (* 0.3f)
                        verblijfsprijs += dagprijs * aantalDagen * (aantalPersonen - 3) * 0.3f;  // > 3 personen                    
                        break;             
                } 
                reisprijs = vluchtprijs + verblijfsprijs; 
                korting = reisprijs * (korting / 100); 
                teBetalen = reisprijs - korting;

                // Afdruk              
                TxtResultaat.Text = $"REISKOST VOLGENS BESTEMMING NAAR {TxtBestemming.Text} \r\n\r\n" +             
                    $"Totale vluchtprijs: {vluchtprijs:c} \r\n" +             
                    $"Totale verblijfsprijs: {verblijfsprijs:c} \r\n" +             
                    $"Totale reisprijs: {reisprijs:c} \r\n" +             
                    $"Korting: {korting:c} \r\n\r\n" +             
                    $"Te betalen : {teBetalen:c}";         
            }             
        } 

        private void ButtonWissen_Click(object sender, RoutedEventArgs e) 
        { 
            TxtBasisvlucht.Text = "0"; 
            TxtBestemming.Clear(); // of: TxtBestemming.Text = string.Empty;
            TxtVluchtklasse.Text = "2"; 
            TxtBasisprijs.Text = "0"; 
            TxtAantalDagen.Text = "0"; 
            TxtAantalPersonen.Text = "0"; 
            TxtKortingspercentage.Text = "0"; 
            TxtResultaat.Clear(); 
            
            TxtBestemming.Focus(); 
        }

        private void ButtonAfsluiten_Click(object sender, RoutedEventArgs e) 
        { 
            Close(); 
        }

        private void TxtVluchtklasse_GotFocus(object sender, RoutedEventArgs e) 
        { 
            LblVluchtklasse.Visibility = Visibility.Visible; 
        }

        private void TxtVluchtklasse_LostFocus(object sender, RoutedEventArgs e) 
        { 
            LblVluchtklasse.Visibility = Visibility.Hidden; 
        }
    }
}
