﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace CS_Oefening_015
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        // We beginnen met de grootste waarde van een datatype. 
        // De traagste tijd zogezegd
        private int snelsteTijd = int.MaxValue;
        private string snelsteAtleet;
        
        public MainWindow()
        {
            InitializeComponent();
            snelsteAtleet = TxtNaam.Text;
        }
        private void BtnSnelste_Click(object sender, RoutedEventArgs e)
        {
            int uren, minuten, seconden, tijd;
            TxtResultaat.Text = $"De snelste atleet is {snelsteAtleet}\r\ntotaal aantal seconden: { snelsteTijd}\r\n\r\n";
            tijd = snelsteTijd;
            //Gehele deling en uren, minuten worden uit de tijd gehaald
            uren = tijd / 3600; // tijd staat in seconden en er zijn 3600 seconden in een uur
            tijd -=  (uren * 3600); // trek nu de uren van de tijd af (terug omzetten naar seconden omdat tijd in seconden staat)
            minuten = tijd / 60; // tijd staat in seconden en er zijn 60 seconden in een minuut
            tijd -= (minuten * 60); // trek nu de minuten van de tijd af (terug omzetten naar seconden omdat tijd in seconden staat)
            seconden = tijd; // het aantal seconden is de tijd die overblijft
            
            // Voeg deze tekst nog toe aan resultaat tekst (+=)
            // is hetzelfde als zeggen: TxtResultaat.Text = TxtResultaat + ... ;
            TxtResultaat.Text += $"aantal uren: {uren}\r\naantal minuten: {minuten}\r\naantal seconden: {seconden}";
        }
        private void BtnNieuw_Click(object sender, RoutedEventArgs e)
        {
            // Als tijd sneller dan de snelste tijd (tijd is kleiner dan snelsteTijd)
            // maak dan dit de nieuwe snelste atleet
            int aantalSeconden = int.Parse(TxtAantalSec.Text);
            if (aantalSeconden < snelsteTijd)
            {
                snelsteAtleet = TxtNaam.Text;
                snelsteTijd = aantalSeconden;
            }

            TxtNaam.Text = string.Empty;
            TxtAantalSec.Text = string.Empty;
            TxtNaam.Focus();
        }
        private void BtnWissen_Click(object sender, RoutedEventArgs e) 
        { 
            snelsteAtleet = string.Empty; 
            snelsteTijd = int.MaxValue;  // Snelste tijd terug op de traagst mogelijke waarde zetten (int.MaxValue)
            TxtResultaat.Clear(); 
            TxtNaam.Clear(); 
            TxtAantalSec.Clear(); 
            TxtNaam.Focus();
        }
        private void BtnAfsluiten_Click(object sender, RoutedEventArgs e) 
        {
            Close(); 
        }
    }
}
