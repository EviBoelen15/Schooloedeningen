﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace CS_Oefening_012
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void BtnBerekenen_Click(object sender, RoutedEventArgs e)
        {
            float lengte;
            // Controle juistheid van gegevens.
            bool testLengteVader = float.TryParse(TxtLengteVader.Text, out float lengteVader);
            bool testLengteMoeder = float.TryParse(TxtLengteMoeder.Text, out float lengteMoeder);
            if (!testLengteVader || !testLengteMoeder)
            {
                MessageBox.Show("Geef een correcte lengte voor vader en moeder op!", 
                    "Foute invoer", 
                    MessageBoxButton.OK, MessageBoxImage.Warning);
            }
            else if (RadMeisje.IsChecked == true)
            {
                lengte = ((lengteVader + lengteMoeder - 13) / 2) + 4.5f;
                TxtLengteMeisje.Text = lengte.ToString();
            }
            else
            {
                lengte = ((lengteVader + lengteMoeder + 13) / 2) + 4.5f;
                TxtLengteJongen.Text = lengte.ToString();
            }

            TxtLengteMoeder.Focus();
        }

        private void ButtonAfsluiten_Click(object sender, RoutedEventArgs e) 
        { 
            Close(); 
        }
        private void RadMeisje_Checked(object sender, RoutedEventArgs e)
        {
            TxtLengteMeisje.IsEnabled = true;
            TxtLengteJongen.IsEnabled = false;
            TxtLengteJongen.Clear();
        }
        private void RadJongen_Checked(object sender, RoutedEventArgs e)
        {
            TxtLengteJongen.IsEnabled = true;
            TxtLengteMeisje.IsEnabled = false;
            TxtLengteMeisje.Clear();
        }
    }
}
