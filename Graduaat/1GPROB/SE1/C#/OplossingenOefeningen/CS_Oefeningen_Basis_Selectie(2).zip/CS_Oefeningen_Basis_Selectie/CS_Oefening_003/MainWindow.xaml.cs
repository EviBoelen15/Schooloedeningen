﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace CS_Oefening_003
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void BtnMaal_Click(object sender, RoutedEventArgs e)
        {
            float getal1 = Convert.ToSingle(TxtGetal1.Text);     
            float getal2 = Convert.ToSingle(TxtGetal2.Text);
            float resultaat = getal1 * getal2;

            TxtResultaat.Text = Convert.ToString(resultaat);
        }

        private void BtnDeel_Click(object sender, RoutedEventArgs e)
        {
            float getal1 = Convert.ToSingle(TxtGetal1.Text);
            float getal2 = Convert.ToSingle(TxtGetal2.Text);
            float resultaat = getal1 / getal2;

            TxtResultaat.Text = Convert.ToString(resultaat);
        }

        private void BtnPlus_Click(object sender, RoutedEventArgs e)
        {
            float getal1 = Convert.ToSingle(TxtGetal1.Text);
            float getal2 = Convert.ToSingle(TxtGetal2.Text);
            float resultaat = getal1 + getal2;

            TxtResultaat.Text = Convert.ToString(resultaat);
        }
        private void BtnMin_Click(object sender, RoutedEventArgs e)
        {
            float getal1 = Convert.ToSingle(TxtGetal1.Text);
            float getal2 = Convert.ToSingle(TxtGetal2.Text);
            float resultaat = getal1 - getal2;

            TxtResultaat.Text = Convert.ToString(resultaat);
        }

        private void BtnWissen_Click(object sender, RoutedEventArgs e)
        {
            TxtGetal1.Text = "0"; 
            TxtGetal2.Text = "0"; 
            TxtResultaat.Text = string.Empty;

            TxtGetal1.Focus();
        }
    }
}
